import State from "./Hooks/State";
const About = () => {
  return (
    <div>
      <h1>About Page</h1>
      <State />
    </div>
  )
}

export default About
